package main;
import project.*;

public class Main {

	public static void main(String[] args) {
//		COSC602_PB1_TheaterSeating.test();
		COSC602_P4_ExpressionTree.test();
		
		}

}
