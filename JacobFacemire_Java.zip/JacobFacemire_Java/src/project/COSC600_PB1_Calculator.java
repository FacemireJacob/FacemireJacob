package project;

import structure.Calculator;

public class COSC600_PB1_Calculator {

	public static void test() {
		Calculator.run();
	}

}
